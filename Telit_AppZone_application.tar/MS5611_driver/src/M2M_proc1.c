/* $version: 121721  */ 
/*==================================================================================================
                            INCLUDE FILES
==================================================================================================*/

#include <stdio.h>
#include <string.h>
#include <stdarg.h>

#include "m2m_type.h"
#include "m2m_clock_api.h"
#include "m2m_fs_api.h"
#include "m2m_hw_api.h"
#include "m2m_os_api.h"
#include "m2m_os_lock_api.h"
#include "m2m_socket_api.h"
#include "m2m_timer_api.h"
#include "m2m_sms_api.h"
#include "m2m_network_api.h"

#include "MS5611/MS5611.h"

/*==================================================================================================
                            LOCAL CONSTANT DEFINITION
==================================================================================================*/

/*==================================================================================================
                            LOCAL TYPES DEFINITION
==================================================================================================*/

/*==================================================================================================
                            LOCAL FUNCTION PROTOTYPES
==================================================================================================*/

/*==================================================================================================
                            GLOBAL FUNCTIONS PROTOTYPES
==================================================================================================*/

/*==================================================================================================
                            LOCAL MACROS
==================================================================================================*/
#define I2C_SDA 2	//I2C pins
#define I2C_SCL 3

/*==================================================================================================
                            LOCAL VARIABLES
==================================================================================================*/

/*==================================================================================================
                            GLOBAL VARIABLES
==================================================================================================*/

/*==================================================================================================
                            LOCAL FUNCTIONS IMPLEMENTATION
==================================================================================================*/

/*==================================================================================================
                            GLOBAL FUNCTIONS IMPLEMENTATION
==================================================================================================*/
void PrintToUart ( const char *fmt, ... )
{
  INT32 sent;
  va_list arg;
  CHAR buf[256];

  M2M_T_HW_UART_HANDLE uart_handle = M2M_HW_UART_HANDLE_INVALID;

  va_start(arg, fmt);
  vsnprintf(buf, 256, fmt, arg);


  /* Get a UART handle first */
  uart_handle = m2m_hw_uart_open();

  if (uart_handle != M2M_HW_UART_HANDLE_INVALID)
  {
    m2m_hw_uart_write(uart_handle, buf, strlen(buf), &sent);
    m2m_hw_uart_write(uart_handle, "\r\n", 2, &sent);
    m2m_hw_uart_close(uart_handle);
  }

  va_end(arg);
}

/* =================================================================================================
 *
 * DESCRIPTION: Handles events sent to process 1
 *
 * PARAMETERS:  type: event id
 *              param1: addition info
 *              param2: addition info
 *
 * RETURNS:         None.
 *
 * PRE-CONDITIONS:  None.
 *
 * POST-CONDITIONS: None.
 *
 * IMPORTANT NOTES: This process has the highest priority.
 *                  Running complex code here will block other events coming to this task.
 * ============================================================================================== */

INT32 M2M_msgProc1(INT32 type, INT32 param1, INT32 param2)
{
  MS6511_RESULT ret;
  MS5611_DATA data;
  UINT8 i = 1;

  PrintToUart("MS5611 sensor test:\n");

  /* initialize MS5611 sensor */
  ret = MS5611Init(I2C_SDA, I2C_SCL, OSR_4096);

  if(ret != MS5611_RESULT_SUCCESS)
  {
    PrintToUart("Sensor init FAIL: %d\n", ret);
    return -1;
  }
  else
  {
    PrintToUart("Sensor init OK:");
    PrintToUart("I2C SDA -> GPIO: %d", I2C_SDA);
    PrintToUart("I2C SCL -> GPIO: %d", I2C_SCL);
    PrintToUart("Oversampling ratio: 4096\r\n");
  }

  /* get data from the MS5611 sensor and display it */
  while(i)
  {
    ret = MS5611GetData(&data);

    if(ret != MS5611_RESULT_SUCCESS)
    {
      PrintToUart("Bad measure! Error: %d\n", ret);
    }
    else
    {
      PrintToUart("Measure %d:", i++);
      PrintToUart("T: %.2f �C", data.T);
      PrintToUart("P: %.2f hPa\r\n", data.P);
    }

    m2m_os_sleep_ms(3000);
  }

  PrintToUart("MS5611 sensor end of test.\n");

  return 0;
}
  
void M2M_msgProcCompl ( INT8 procId, INT32 type, INT32 result )
{
  /* write code fulfilling the requirements of the M2M project */
}
  
